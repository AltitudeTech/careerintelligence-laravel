<link rel="stylesheet" href="{{ asset('css/flexslider.css') }}" type="text/css" media="all" /><!-- for testimonials -->

<!-- default css files -->
	<link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}" type="text/css" media="all">
	<link rel="stylesheet" href="{{ asset('css/style.css') }}" type="text/css" media="all">
	<link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}" />
<!-- default css files -->
	
<!--web font-->
<link href="//fonts.googleapis.com/css?family=Federo" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
<!--//web font-->