<!-- <div class="col-md-6 services-bottom">
			<div class="col-md-6 agileits_w3layouts_about_counter_left">
				<div class="countericon">
					<i class="glyphicon glyphicon-tasks" aria-hidden="true"></i>
				</div>
				<div class="counterinfo">
					<p class="counter">436</p> 
					<h3>Major Clients</h3>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-6 agileits_w3layouts_about_counter_left">
				<div class="countericon">
					<i class="glyphicon glyphicon-erase" aria-hidden="true"></i>
				</div>
				<div class="counterinfo">
					<p class="counter">29</p> 
					<h3>Countries</h3>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
			<div class="col-md-6 agileits_w3layouts_about_counter_left">
				<div class="countericon">
					<i class="fa fa-calendar" aria-hidden="true"></i>
				</div>
				<div class="counterinfo">
					<p class="counter">22000</p>
					<h3>Candidates Placed</h3>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-md-6 agileits_w3layouts_about_counter_left">
				<div class="countericon">
					<i class="fa fa-thumbs-up" aria-hidden="true"></i>
				</div>
				<div class="counterinfo">
					<p class="counter" style="margin-bottom: 0px ; padding-bottom: 0px">150</p><small style="color: #ffffff ; font-style: italic; ">(combined years of experience)</small>
					<h3>Top Management</h3>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
	</div> -->
<!-- //Counter -->
<!-- Clients -->
	<!-- <div class=" col-md-6 clients">
			<h3>Testimonials</h3>
			<span></span>
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation .</p>
								<div class="client">
									<img src="images/c1.jpg" alt="" />
									<h5>Brian Fantana</h5>
									<div class="clearfix"> </div>
								</div>
						</li>
						<li>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation .</p>
								<div class="client">
								<img src="images/c2.jpg" alt="" />
									<h5>Brick Tamland</h5>
									<div class="clearfix"> </div>
								</div>
						</li>
						<li>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation .</p>
								<div class="client">
								<img src="images/c3.jpg" alt="" />
									<h5>Ron Burgundy</h5>
									<div class="clearfix"> </div>
								</div>
						</li>
						<li>
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation .</p>
								<div class="client">
								<img src="images/c4.jpg" alt="" />
									<h5>Arturo Mendez</h5>
									<div class="clearfix"> </div>
								</div>
						</li>
					</ul>
				</div>
			</section>
	</div>
	<div class="clearfix"> </div> -->