<div class="more-button text-center bg-primary" style="padding: 30px ; background-color: rgba(59,89,152,0.7); ">
	<form>
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<!-- <label for="">Search Nigerian Jobs</label> -->
					<input type="text" style="width: 100% !important;" class="form-control" id="jobs" placeholder="Keywords : Jobs">
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<!-- <label for="">Search Nigerian Locations</label> -->
					<input type="text" class="form-control" id="location" style="width: 100% !important;" placeholder="Keywords : Country, State, City">
				</div>
			</div>
			
			<a href="" style="border:2px solid #b2b2b2; color: #000000; " class="hvr-bounce-to-bottom scroll">Search Jobs</a>
		</div>
	</form>
</div>