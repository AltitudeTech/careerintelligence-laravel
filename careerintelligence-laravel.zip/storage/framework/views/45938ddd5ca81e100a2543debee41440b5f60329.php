<?php $__env->startSection('title','Candidate'); ?>

<?php $__env->startSection('css'); ?>
	##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
	<style type="text/css">
		.banner1 {
		    background: url(<?php echo e(asset('images/employers-x.jpg')); ?>) no-repeat  0px 0px;
		    background-size: cover;
		    background-position: center;
		    -webkit-background-size: cover;
		    -moz-background-size: cover;
		    -o-background-size: cover;
		    -ms-background-size: cover;
		    position: relative;
			min-height:500px;
		}
		.wthree-different-dot1 {
			min-height:500px;
		}
		.agileits_agile_about p{
			margin: 10px auto ;
			letter-spacing: 1px ;
			line-height: 30px ;
			text-align: justify;
		}

		.agileits_agile_about img{
			float: left ;
			margin: 20px 15px 0px 0px ;
			width: 40% ;
		}
	</style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('banner'); ?>

	<div class=" banner banner1">
		<div class="wthree-different-dot1">
			<!-- header -->
			<div class="header">
				<div class="container">
					<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<!-- //header -->
					<h2>Employers</h2>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
##parent-placeholder-964a3b119be846ddf05b003479487e359c1fa3da##

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
	<div class="agile_about contact" id="contact">

	<div class="agileits_agile_about">
		<div class="container">	
			<div class="row">
					<p>
						Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores nihil dolorem sunt, nisi nulla laudantium. Est iste, vel doloribus ducimus error provident cum corporis, nihil placeat laboriosam, ipsum odio dolorem!
						Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores nihil dolorem sunt, nisi nulla laudantium. Est iste, vel doloribus ducimus error provident cum corporis, nihil placeat laboriosam, ipsum odio dolorem!
					</p>
					<p>
						Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores nihil dolorem sunt, nisi nulla laudantium. Est iste, vel doloribus ducimus error provident cum corporis, nihil placeat laboriosam, ipsum odio dolorem!
					</p>
					<div class="col-md-9">
							<div class="row">
								<style>
									input, textarea{
										border-radius: 0 !important;
										resize: none ;
									}
								</style>
									<div style="margin-top: 40px;">
										<?php echo Form::open(['action' => 'RecruitingController@store' , 'method'=>'POST']); ?>

											<div class="col-md-6">
												<fieldset class="form-group">
													<input type="hidden" value="newR" name="newR" id="newR">
													<label for="organizationName"><span class="text-danger">*</span>First Name</label>
													<input type="text" name="organizationName" class="form-control" id="organizationName" required>
												</fieldset>	
											</div>
		
											<div class="col-md-6">	
												<fieldset class="form-group">
													<label for="contactName"><span class="text-danger">*</span>Last Name</label>
													<input type="text" name="contactName" class="form-control" id="contactName" required>
												</fieldset>
											</div>
		
											
											<div class="col-md-12">	
												<fieldset class="form-group">
													<label for="contactEmail"><span class="text-danger">*</span>Email Address</label>
													<input type="email" name="email" class="form-control" id="contactEmail" required>
												</fieldset>
											</div>

											<div class="col-md-12">
												<fieldset class="form-group">
													<label for="jobTitle"><span class="text-danger">*</span>Company's Name</label>
													<input type="text" name="jobTitle" class="form-control" id="jobTitle" required>
												</fieldset>	
											</div>
											<div class="col-md-6">
													<fieldset class="form-group">
														<input type="hidden" value="newR" name="newR" id="newR">
														<label for="organizationName"><span class="text-danger">*</span>Job Title</label>
														<input type="text" name="organizationName" class="form-control" id="organizationName" required>
													</fieldset>	
												</div>
			
												<div class="col-md-6">	
													<fieldset class="form-group">
														<label for="contactName"><span class="text-danger">*</span>Website</label>
														<input type="text" name="contactName" class="form-control" id="contactName" required>
													</fieldset>
												</div>
											<div class="col-md-12">	
												<fieldset class="form-group">
													<label for="contactEmail">Message</label><br/>
													<textarea name="" id="" cols="30" rows="10" class="form-control"></textarea>
												</fieldset>
											</div>
											<br/>
		
											<div class="col-md-offset-8 col-md-4" style="margin-top : 10px ;">
												<input type="submit" value="Register" class="btn btn-block btn-success" name="">
											</div>
										<?php echo Form::close(); ?>

										<div class="clearfix"></div>
									</div>	
								</div>
							</div>
					<div class="col-md-3">
						<?php echo $__env->make('serviceside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</div>
				</div>
		</div>
	</div>
</div>
<!-- //contact -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>