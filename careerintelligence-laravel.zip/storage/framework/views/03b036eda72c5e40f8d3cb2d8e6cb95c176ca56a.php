<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>404 Error</title>
</head>
<body>
	<h1>Error Page</h1>
	<h2><?php echo e($error); ?></h2>
</body>
</html>