
<nav class="navbar navbar-default">
	<div class="navbar-header">
	  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	  </button>
		<div class="w3layouts-logo">
			<a href="<?php echo e(route('index')); ?>"><img style="max-width: 200px" src="<?php echo e(asset('images/logo2.png')); ?>" class="img-responsive" alt=""></a>
		</div>
	</div>

	
	<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
		<nav>
			<ul class="nav navbar-nav">
				
				<li class="
					<?php if($title == 'Home'): ?>
						<?php echo e('active'); ?>

					<?php endif; ?>
				"><a href="<?php echo e(route('index')); ?>">Home</a></li>

				<li class="dropdown
					<?php if($title == 'About'): ?>
						<?php echo e('active'); ?>

					<?php endif; ?>
				"><a href="#" class="dropdown-toggle" data-hover="Pages" data-toggle="dropdown">About Us <b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li><a href="<?php echo e(route('mission')); ?>">Mission & Values </a></li>
						<li><a href="<?php echo e(route('companystructure')); ?>">Company Structure</a></li>
						<li><a href="<?php echo e(route('franchise')); ?>">franchise</a></li>
						<li><a href="<?php echo e(route('citv')); ?>">CITV</a></li>
						<li><a href="<?php echo e(route('market')); ?>">Market</a></li>
						<li><a href="<?php echo e(route('citc')); ?>">CITC</a></li>
						<li><a href="<?php echo e(route('join-us')); ?>">Join Us</a></li>
					</ul>
			  </li>
				
				

				<li class="dropdown
				"><a href="#" class="dropdown-toggle" data-hover="Pages" data-toggle="dropdown">Services <b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li><a href="<?php echo e(route('permanentplacement')); ?>">Permanent Placement</a></li>
						<li><a href="<?php echo e(route('temporaryplacement')); ?>">Temporary Placement</a></li>
						<li><a href="<?php echo e(route('internships')); ?>">Internships</a></li>
						<li><a href="<?php echo e(route('outplacement')); ?>">Outplacement</a></li>
						<li><a href="<?php echo e(route('featureddigitalcampaign')); ?>">Featured Digital Campaign</a></li>
						<li><a href="<?php echo e(route('digitalizedvideo')); ?>">Digitalized Video Assessment and  Interview</a></li>
						<li><a href="<?php echo e(route('recruitmentprocess')); ?>">Recruitment Process Outsourcing</a></li>
						<li><a href="<?php echo e(route('internationalrecruitment')); ?>">International Recruitment</a></li>
						<li><a href="<?php echo e(route('hr-services')); ?>">HR Services</a></li>
						<li><a href="<?php echo e(route('labour-market-research')); ?>">Labour Market Research</a></li>
						<li><a href="<?php echo e(route('salaryandremuneration')); ?>">Salaries & Remuneration Bench marking</a></li>
						<li><a href="<?php echo e(route('executiveservices')); ?>">Executive Services</a></li>
					</ul>
			  </li>
				<li class="dropdown
				"><a href="#" class="dropdown-toggle" data-hover="Pages" data-toggle="dropdown">Sectors <b class="caret"></b></a>
					<ul class="dropdown-menu">
						<?php echo $__env->make('sectordrop', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</ul>
			  </li>

				
				<li class="dropdown
					<?php if($title == 'Login' || $title == 'Register'): ?>
						<?php echo e('active'); ?>

					<?php endif; ?>
				"><a href="#" class="dropdown-toggle" data-hover="Pages" data-toggle="dropdown">Login <b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li><a href="#" data-toggle="modal" data-target="#ModalLoginForm" data-dismiss="modal">Candidate</a></li>
						<li><a href="#" data-toggle="modal" data-target="#empModalLoginForm">Employer</a></li>
					</ul>
				  </li>
				<li class="
					<?php if($title == 'Join Us'): ?>
						<?php echo e('active'); ?>

					<?php endif; ?>
				"><a href="<?php echo e(route('join-us')); ?>">JOIN US</a></li>
				<li class="
					<?php if($title == 'CITV'): ?>
						<?php echo e('active'); ?>

					<?php endif; ?>
				"><a href="<?php echo e(route('citv')); ?>"> CITV</a></li>


				<li class="
					<?php if($title == 'Contact'): ?>
						<?php echo e('active'); ?>

					<?php endif; ?>
				"><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
				<style type="text/css">
					li#last a,li#last a:hover{
						border:none !important;
						color:#d35400;
						font-weight: bold;
					}
				</style>
				<li id="last" class="
					<?php if($title == 'Contact'): ?>
						<?php echo e('active'); ?>

					<?php endif; ?>
				"><a href="<?php echo e(route('submitcv')); ?>">Send CV</a></li>
			</ul>
		</nav>
	</div>
</nav>					