<div class="list-group">
	<a class="list-group-item active text-center">SERVICES</a>
	<a href="<?php echo e(route('permanentplacement')); ?>" class="list-group-item">Permanent Placement</a>
	<a href="<?php echo e(route('temporaryplacement')); ?>" class="list-group-item">Temporary Placement</a>
	<a href="<?php echo e(route('internships')); ?>" class="list-group-item">Internships</a>
	<a href="<?php echo e(route('outplacement')); ?>" class="list-group-item">Outplacement</a>
	<a href="<?php echo e(route('featureddigitalcampaign')); ?>" class="list-group-item">Featured Digital Campaign</a>
	<a href="<?php echo e(route('digitalizedvideo')); ?>" class="list-group-item">Digitalized Video Assessment Interview</a>
	<a href="<?php echo e(route('recruitmentprocess')); ?>" class="list-group-item">Recruitment Process Outsourcing
	<a href="<?php echo e(route('internationalrecruitment')); ?>" class="list-group-item">International Recruitment</a>
	<a href="<?php echo e(route('hr-services')); ?>" class="list-group-item">HR Services</a>
	<a href="<?php echo e(route('labour-market-research')); ?>" class="list-group-item">Labour Market Research</a>
	<a href="<?php echo e(route('salaryandremuneration')); ?>" class="list-group-item">Salaries & Remuneration Bench Marking</a>
	<a href="<?php echo e(route('executiveservices')); ?>" class="list-group-item">Executive Services</a>

	<a class="list-group-item active text-center">SECTORS</a>
	<?php $__currentLoopData = App\Admin\Sector::take(11)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e(route('sectordisplay', ['secId'=> $sector->id ])); ?>" class="list-group-item"><?php echo e($sector->name); ?></a>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<a href="<?php echo e(route('sector')); ?>" class="list-group-item text-right">More Sectors</a>
	
</div>