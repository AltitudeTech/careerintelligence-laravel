<?php $__env->startSection('title','Join Us'); ?>

<?php $__env->startSection('css'); ?>
	##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
	<style type="text/css">
		.banner1 {
		    background: url(<?php echo e(asset('images/joinus.jpg')); ?>) no-repeat  0px 0px;
		    background-size: cover;
		    background-position: center;
		    -webkit-background-size: cover;
		    -moz-background-size: cover;
		    -o-background-size: cover;
		    -ms-background-size: cover;
		    position: relative;
			min-height:500px;
		}
		.wthree-different-dot1 {
			min-height:500px;
		}
		.well , .btn , .form-control
		{
			border-radius: 0px ;
		}
		.lead{
			font-size : 15px ;
		}
	</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>

	<div class=" banner banner1">
		<div class="wthree-different-dot1">
			<!-- header -->
			<div class="header">
				<div class="container">
					<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<!-- //header -->
					<h2>JOIN US</h2>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
##parent-placeholder-964a3b119be846ddf05b003479487e359c1fa3da##

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

	<section class="portfolio-agileinfo" id="portfolio">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<h4>Sectors</h4>
					<div aria-multiselectable="true" role="tablist" id="accordion" class="panel-group">
						<?php $__currentLoopData = App\Admin\Sector::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="panel panel-default"> <a title="<?php echo e(strtolower($sec->name)); ?>" 
								href="<?php echo e(route('sectordisplay', ['secId'=> $sec->id ])); ?>"
								role="tab" class="panel-heading collapsed">
								<span class="panel-title"><?php echo e($sec->name); ?></span> </a>
							     	<div aria-labelledby="heading<?php echo e($sec->id); ?>" role="tabpanel" class="panel-collapse collapse" id="collapse<?php echo e($sec->id); ?>" aria-expanded="false">
							            <ul class="list-group">
							                <a href="#" class="list-group-item"><?php echo e($sec->name . ' (No category yet)'); ?></a>
						                </ul>
							        </div>
						    </div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="col-md-8">
					<div class="gallery-grids">
						<div class="row">
							<div class="well" style="margin-top: 20px;background-color: #EC971F;">
								<h1 style="font-size: 22px; font-weight: bolder;">RECRUITING NOW</h1>
							</div>
						</div>
						<div class="row">
							<div class="well" style="margin-top: 20px;">
									<img src="images/specmail.jpg" class="img-responsive" alt="Specialization - CI" />
								<p class="lead" style="margin-top: 20px;">
									In the complicated world of finding the best talent, our unparalleled recruiting expertise means the people you want to talk to are already talking to us.
								</p>
							</div>	
						</div>

						

						
					</div>
				</div>
			</div>	
		</div>	
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>