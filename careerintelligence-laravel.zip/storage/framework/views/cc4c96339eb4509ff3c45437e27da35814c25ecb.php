<div aria-multiselectable="true" role="tablist" id="accordion" class="panel-group">
	<?php if(count($sector) > 0): ?>
	<?php
		$count = 0 ;
	?>
		<?php $__currentLoopData = $sector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="panel panel-default"> <a title="<?php echo e(strtolower($sec->name)); ?>" 
				<?php if(count($sec->categories) > 0): ?>
				href="#collapse<?php echo e($sec->id); ?>"
				aria-controls="collapse<?php echo e($sec->id); ?>" 
				aria-expanded="false" 
				data-parent="#accordion" 
				data-toggle="collapse" 
				id="heading<?php echo e($sec->id); ?>" 
				<?php else: ?>
				href="<?php echo e(route('sectordisplay', ['secId'=> $sec->id ])); ?>"
				<?php endif; ?> 
				role="tab" class="panel-heading collapsed">
				<?php if(count($sec->categories) > 0): ?>
				<span class="glyphicon glyphicon-plus pull-right"></span>
				<?php endif; ?>
				<span class="panel-title"><?php echo e($sec->name); ?></span> </a>
				<?php if(count($sec->categories) > 0): ?>
					<div aria-labelledby="heading<?php echo e($sec->id); ?>" role="tabpanel" class="panel-collapse collapse" id="collapse<?php echo e($sec->id); ?>" aria-expanded="false">
			            <ul class="list-group">
							<?php $__currentLoopData = $sec->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                    <a href="<?php echo e(route('sec-cat-recruit', ['specCat'=> $secCat->name, 'q' => $secCat->id ])); ?>" class="list-group-item"><?php echo e($secCat->name); ?></a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </ul>
			        </div>
			     <?php else: ?>
			     	<div aria-labelledby="heading<?php echo e($sec->id); ?>" role="tabpanel" class="panel-collapse collapse" id="collapse<?php echo e($sec->id); ?>" aria-expanded="false">
			            <ul class="list-group">
			                <a href="#" class="list-group-item"><?php echo e($sec->name . ' (No category yet)'); ?></a>
		                </ul>
			        </div>
				<?php endif; ?>
		        
		    </div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
</div>