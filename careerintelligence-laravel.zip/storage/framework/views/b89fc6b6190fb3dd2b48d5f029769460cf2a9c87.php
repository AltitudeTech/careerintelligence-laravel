<?php
    use App\Http\Controllers\Admin\SectorController;
    $sectors = new SectorController();
    $sector = $sectors->getAllSectors();
?>

<?php $__currentLoopData = $sector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(route('sectordisplay', ['secId'=> $sec->id ])); ?>"><?php echo e($sec->name); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>