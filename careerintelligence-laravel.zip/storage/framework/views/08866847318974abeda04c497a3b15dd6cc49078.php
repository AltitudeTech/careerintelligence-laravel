<!DOCTYPE html>
<html lang="en">
<!-- Head -->
<head>
<title> <?php echo $__env->yieldContent('title'); ?>	 | Career Intelligence </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<meta name="keywords" content="" />


<?php $__env->startSection('css'); ?>
	<?php echo $__env->make('layouts.cssimport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldSection(); ?>

	
</head>

<!-- Body -->
<body>

<!-- banner -->
	<?php echo $__env->yieldContent('banner'); ?>	
	<!-- //banner -->
<!-- Modal1 -->
	<?php $__env->startSection('modal'); ?>

		<div id="ModalLoginForm" class="modal fade" style="margin-top: 150px;">
		    <div class="modal-dialog" role="document">
		        <div class="modal-content" style="border-radius:0px !important;">
		            <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
		                <h4 class="modal-title">Candidate Login</h4>
		            </div>
		            <div class="modal-body">
		                <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="col-md-4 control-label">Password</label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control" name="password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <button type="submit" class="btn btn-info">
                                        Login
                                    </button>

                                    <span>OR</span>

                                    <button type="button" style="border-radius: 0px ;" class="btn btn-primary"><span style="border: 1px solid #fff; padding: 5px ; border-radius: 2px ;" class="fa fa-facebook"></span>
                                        Login with Facebook
                                    </button>

                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        Forgot Your Password?
                                    </a>
                                </div>
                            </div>
                        </form>
		            </div>
		        </div><!-- /.modal-content -->
		    </div><!-- /.modal-dialog -->
		</div>

        <div id="empModalLoginForm" class="modal fade" style="margin-top: 150px;">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="border-radius:0px !important;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Employer Login</h4>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="col-md-4 control-label">Password</label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control" name="password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <button type="submit" class="btn btn-info">
                                        Login
                                    </button>

                                    <span>OR</span>

                                    <button type="button" style="border-radius: 0px ;" class="btn btn-primary"><span style="border: 1px solid #fff; padding: 5px ; border-radius: 2px ;" class="fa fa-facebook"></span>
                                        Login with Facebook
                                    </button>

                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        Forgot Your Password?
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>

        <div id="empModalRegForm" class="modal fade">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="border-radius:0px !important;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h3 class="modal-title">Employer</h3>
                    </div>
                    <div class="modal-body" style="padding: 0px 60px;">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
                                    <input id="firstname" type="text" name="firstname" placeholder="First name" value="<?php echo e(old('firstname')); ?>" required autofocus>
                                    <?php if($errors->has('firstname')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('firstname')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                                    <input id="lastname" type="text" name="lastname" placeholder="Last name" value="<?php echo e(old('lastname')); ?>" required autofocus>
                                    <?php if($errors->has('lastname')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('lastname')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                                    <input id="phone" type="text" name="phone" placeholder="Phone" value="<?php echo e(old('phone')); ?>" required autofocus>
                                    <?php if($errors->has('phone')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <input id="email" type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('company') ? ' has-error' : ''); ?>">
                                    <input id="company" type="text" name="company" placeholder="Company" value="<?php echo e(old('company')); ?>" required autofocus>
                                    <?php if($errors->has('company')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('company')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('jobtitle') ? ' has-error' : ''); ?>">
                                    <input id="jobtitle" type="text" name="jobtitle" placeholder="Job Title" value="<?php echo e(old('jobtitle')); ?>" required autofocus>
                                    <?php if($errors->has('jobtitle')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('jobtitle')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group<?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
                                    <input id="website" type="text" name="website" placeholder="Website" value="<?php echo e(old('website')); ?>" required autofocus>
                                    <?php if($errors->has('website')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('website')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group<?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
                                    <?php if($errors->has('website')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('website')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                    <textarea style="width: 100% ; resize: none;" rows="5"></textarea>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <button type="button" style="border-radius: 0px;" class="btn btn-block btn-danger btn-lg">
                                        Register
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>

        <div id="canModalRegForm" class="modal fade">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="border-radius:0px !important;">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h3 class="modal-title">Candidate</h3>
                    </div>
                    <div class="modal-body" style="padding: 0px 60px;">
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
                                    <input id="firstname" type="text" name="firstname" placeholder="First name" value="<?php echo e(old('firstname')); ?>" required autofocus>
                                    <?php if($errors->has('firstname')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('firstname')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                                    <input id="lastname" type="text" name="lastname" placeholder="Last name" value="<?php echo e(old('lastname')); ?>" required autofocus>
                                    <?php if($errors->has('lastname')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('lastname')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                                    <input id="phone" type="text" name="phone" placeholder="Phone" value="<?php echo e(old('phone')); ?>" required autofocus>
                                    <?php if($errors->has('phone')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <input id="email" type="text" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group<?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
                                    <?php if($errors->has('website')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('website')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                    <textarea style="width: 100% ; resize: none;" rows="5"></textarea>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <button type="button" style="border-radius: 0px ;" class="btn btn-danger btn-block btn-lg">
                                        Register
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
	<?php echo $__env->yieldSection(); ?>	
<!-- //Modal1 -->

<!-- welcome -->
<?php echo $__env->yieldContent('body'); ?>
<!-- //subscribe section -->

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- //copyright -->

<!-- Default-JavaScript-File -->

<?php echo $__env->make('layouts.jsimport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-59c55ee9a6332134"></script>
<script type="text/javascript">
    function bs_input_file() {
    $(".input-file").before(
        function() {
            if ( ! $(this).prev().hasClass('input-ghost') ) {
                var element = $("<input type='file' class='input-ghost' style='visibility:hidden; height:0'>");
                element.attr("name",$(this).attr("name"));
                element.change(function(){
                    element.next(element).find('input').val((element.val()).split('\\').pop());
                });
                $(this).find("button.btn-choose").click(function(){
                    element.click();
                });
                $(this).find("button.btn-reset").click(function(){
                    element.val(null);
                    $(this).parents(".input-file").find('input').val('');
                });
                $(this).find('input').css("cursor","pointer");
                $(this).find('input').mousedown(function() {
                    $(this).parents('.input-file').prev().click();
                    return false;
                });
                return element;
            }
        }
    );
}
$(function() {
    bs_input_file();
});
</script>

</body>

<?php echo $__env->yieldContent('basicjs'); ?>
<!-- //Body -->
</html>